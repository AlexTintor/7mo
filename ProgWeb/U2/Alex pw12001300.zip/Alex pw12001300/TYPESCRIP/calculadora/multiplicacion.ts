const multiplicar = (a,b,imprimir) =>{
    console.log(imprimir,a*b);
}
multiplicar(2,4,"El resultado es: ");
