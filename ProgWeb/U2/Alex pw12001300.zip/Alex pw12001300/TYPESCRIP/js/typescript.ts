let mensaje = "Hola Javascript";
console.log(mensaje);
console.log(typeof(mensaje));

mensaje=2;
console.log(mensaje);
console.log(typeof(mensaje));