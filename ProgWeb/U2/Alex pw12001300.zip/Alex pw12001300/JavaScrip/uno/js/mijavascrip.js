document.write("<h1>Programacion Web</h1>")
// console.log
// alert("Ayuda, simiored me viola")
console.log("Hacia la consola")
console.error("Lanza un error")
let x = 1; //debilmente tipado
console.log(x)
//tipos de datos:
/*
    Undefined
    Boolean
    Number
    String
    BigInt
    Symbol
    Null
    Object
    Function
*/
let esPW = false
if(esPW){
    console.log("Estamos en clase");
}else{
    console.log("Estamos en clase");
}
let numero = -3434343.34343;
console.log(numero)
//Cadena Strings
let cadena = "una cadena"
let cadena2 = "una cadena"
let cadena3 = '"una cadena"'+numero
console.log(cadena3)

let id1 = Symbol("id");
let id2 = Symbol("id");

console.log(id1)
let usuario={nombre:"Martin",[id1]: 48}
console.log('${usuario.nombre} ${usuario.[id1]}') //demonio franses

let variablesnulas = null
console.log(variablesnulas)

const PI = 3.1416
console.log(PI) 

//ARREGLOS
let arreglo = [];
console.log(arreglo);
arreglo.push(4);
arreglo.pop()
//Sacar e; ;aflemmf,n slknrwf ;iy46 