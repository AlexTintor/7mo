let titulo=document.getElementById("titulo");
// let titulo = document.querySelector("#titulo");
console.log(titulo);
let principal=document.querySelector(".principal");
console.log(principal);
let lista=document.querySelectorAll("ul.lista > li")
console.log(lista)

titulo.innerText="Estructurando el DOM - VB";
titulo.innerHTML="<em>Nuevo DOM</em>";

let foto = document.querySelector("img");
foto.setAttribute("src","img/logo_javascript2.png");
foto.classList.add("foto_cambio");//css

principal.style.background="#FFCC00";

//eliminar una cosa
let extra=document.querySelector(".extra");
document.body.removeChild(extra)

//agregar un nuevo elemento "NUEVO article"
let nuevoarticle=document.createElement("article");
nuevoarticle.innerText="NUEVO article";
nuevoarticle.style.color="white";
nuevoarticle.style.background="purple";
nuevoarticle.style.padding="20px";
document.body.appendChild(nuevoarticle);

let boton=document.querySelector("button");
// boton.addEventListener("click",() => {
//     alert("Boton presionado")
// });

muestrMensaje = (mensaje) => {
    alert(mensaje);
}
boton.addEventListener("click",muestrMensaje.bind(null,"Aqui"))