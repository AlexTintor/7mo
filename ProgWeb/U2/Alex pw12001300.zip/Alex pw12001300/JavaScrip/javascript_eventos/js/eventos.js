let elemento=document.querySelector("#elemento");
let agregar = document.querySelector("#agregar");
let lista = document.querySelector("#listadinamica");
let texto = document.querySelector(".texto");
elemento.focus();

agregar.addEventListener("click", () => {
    if(elemento.value.trim() !=""){
        let nuevoelemento = document.createElement("li");
        nuevoelemento.innerText=elemento.value;
        lista.appendChild(nuevoelemento);
        elemento.value = "";
        elemento.focus();
    }
});

elemento.addEventListener("keydown", (e) => {
    if(e.key == "Enter"){
        agregar.click();
    }
});

//Arrastrar
let arrastra = document.querySelector("#arrastra");
let zonasoltar = document.querySelector("#zonasoltar");

arrastra.addEventListener("dragstart", function(e){
    // this.style.border="5px solid red";
});

zonasoltar.addEventListener("dragover", function(e){
    //zonasoltar olvida que no se pueden
    //arrastar elementos sobre el
    event.preventDefault();
    // zonasoltar.style.background="red"////
    // elemento.style.background="yellow"////
});
zonasoltar.addEventListener("drop", function(e){
    this.append(arrastra)
    zonasoltar.style.background="white";////
    elemento.style.background="white";////
    arrastra.style.border="none";
    texto.style.display="none";
})
zonainicial.addEventListener("dragover", function(e){
    //zonasoltar olvida que no se pueden
    //arrastar elementos sobre el
    event.preventDefault();
    // zonasoltar.style.background="red"////
    // elemento.style.background="yellow"////
});
zonainicial.addEventListener("drop", function(e){
    this.append(arrastra)
    arrastra.style.border="none";
    texto.style.display="none";
})